# Mass Mail Dispatcher - Exposys Data Labs Internship Project


## Objective of the Project

-	To design an attractive and user-friendly GUI, which help them to fill the information clearly.
-	To create SMTP server for sending mails without asking the email password from the user.
-	To provide a very rich text editor for the user to edit their email content.
-	To valid the recipient’s mail Id.
# maildispatch
